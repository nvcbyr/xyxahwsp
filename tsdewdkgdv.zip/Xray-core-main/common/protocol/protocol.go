package protocol // import "github.com/xtls/xray-core/common/protocol"

//go:generate go run github.com/xtls/xray-core/common/errors/errorgen
